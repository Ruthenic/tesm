hello welcome to tesm  
# Instructions
download python  
write the tesm code  
ensure python is installed  
run the interpreter in the console with `python main.py tesm_file.tesm`  
make sure python is installed    
you have now learnt how to use the most epicness language ~~and/or sin~~ in the world, congrats  
now you just have to make sure that you have python installed  
# Notes
compatibilty with anything that isn't Linux is not guaranteed 
